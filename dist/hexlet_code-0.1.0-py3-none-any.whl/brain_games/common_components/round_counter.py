def count(count_number):
    if count_number == 3:
        return True
    else:
        return False