#!/usr/bin/env python

from brain_games.common_components.greetings import welcome_user


def main():
    welcome_user()


if __name__ == '__main__':
    main()
