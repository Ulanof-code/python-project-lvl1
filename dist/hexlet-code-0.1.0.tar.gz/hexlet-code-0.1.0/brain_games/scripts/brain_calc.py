#!/usr/bin/env python

from brain_games.games.game_calc import start_calc_game


def main():
    start_calc_game()


if __name__ == '__main__':
    main()
